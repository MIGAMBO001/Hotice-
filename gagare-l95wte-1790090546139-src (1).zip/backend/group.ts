import { db } from '@appdeploy/sdk';

type Group = {
  id?: string;
  type: 'group';
  name: string;
  description?: string;
  ownerId: string;
  participantIds: string[];
  chatId: string;
  createdAt: string;
  updatedAt: string;
  inviteCode?: string;
  joinApproval: boolean;
};

type Membership = {
  id?: string;
  groupId: string;
  userId: string;
  role: 'owner' | 'admin' | 'member';
  joinedAt: string;
  leftAt?: string;
  restricted?: boolean;
};

async function getGroupRecord(id: string) {
  const [g] = await db.get<Group>('groups', [id]);
  return g ? { ...g, id } : null;
}

async function userByUsername(username: string) {
  const { items } = await db.list<any>('users', { limit: 50 });
  return items.find(
    x => String(x.username ?? '').toLowerCase() === username.trim().toLowerCase() &&
      String(x.accountStatus ?? 'active') === 'active'
  ) ?? null;
}

async function membership(groupId: string, userId: string) {
  const { items } = await db.list<Membership>('group_members', { limit: 500 });
  return items.find(m => m.groupId === groupId && m.userId === userId && !m.leftAt) ?? null;
}

function isManager(m: Membership | null) {
  return m?.role === 'owner' || m?.role === 'admin';
}

function inviteCode() {
  return crypto.randomUUID().replace(/-/g, '').slice(0, 12).toUpperCase();
}

export async function createGroup(ownerId: string, name: string, description: string) {
  if (name.trim().length < 2 || name.trim().length > 80) throw new Error('INVALID_GROUP_NAME');
  const now = new Date().toISOString();
  const chatId = crypto.randomUUID();
  const groupId = crypto.randomUUID();
  const code = inviteCode();

  await db.add('chats', [{
    id: chatId,
    type: 'group',
    groupId,
    participantIds: [ownerId],
    createdAt: now,
    updatedAt: now,
    lastMessageAt: null,
    archivedBy: [],
    mutedBy: [],
    hiddenBy: []
  }]);

  const [id] = await db.add('groups', [{
    type: 'group',
    name: name.trim(),
    description: description.trim().slice(0, 500),
    ownerId,
    participantIds: [ownerId],
    chatId,
    createdAt: now,
    updatedAt: now,
    inviteCode: code,
    joinApproval: false
  }]);

  if (!id) throw new Error('GROUP_CREATE_FAILED');
  await db.add('group_members', [{
    groupId: id,
    userId: ownerId,
    role: 'owner',
    joinedAt: now,
    restricted: false
  }]);

  return {
    id,
    chatId,
    name: name.trim(),
    description: description.trim().slice(0, 500),
    role: 'owner',
    memberCount: 1,
    inviteCode: code
  };
}

export async function listGroups(userId: string) {
  const { items } = await db.list<Group>('groups', { limit: 100 });
  return items
    .filter(g => g.participantIds.includes(userId))
    .map(g => ({
      id: g.id,
      chatId: g.chatId,
      name: g.name,
      description: g.description ?? '',
      role: g.ownerId === userId ? 'owner' : 'member',
      memberCount: g.participantIds.length
    }));
}

export async function getGroup(userId: string, id: string) {
  const g = await getGroupRecord(id);
  const me = await membership(id, userId);
  if (!g || !me) throw new Error('GROUP_NOT_FOUND');

  const { items } = await db.list<Membership>('group_members', { limit: 500 });
  const activeMembers = items.filter(m => m.groupId === id && !m.leftAt);
  const users = await db.list<any>('users', { limit: 100 });

  return {
    id: g.id,
    chatId: g.chatId,
    name: g.name,
    description: g.description ?? '',
    ownerId: g.ownerId,
    inviteCode: isManager(me) ? (g.inviteCode ?? null) : null,
    joinApproval: g.joinApproval,
    members: activeMembers.map(m => {
      const u = users.items.find(x => String(x.id) === m.userId);
      return {
        userId: m.userId,
        username: u?.username ?? '',
        realName: u?.realName ?? '',
        role: m.role,
        restricted: Boolean(m.restricted)
      };
    })
  };
}

export async function addMembers(userId: string, id: string, usernames: string[]) {
  const g = await getGroupRecord(id);
  const me = await membership(id, userId);
  if (!g || !me) throw new Error('GROUP_NOT_FOUND');
  if (!isManager(me)) throw new Error('PERMISSION_DENIED');

  const existing = g.participantIds;
  const added: string[] = [];

  for (const name of usernames.slice(0, 50)) {
    const u = await userByUsername(name);
    if (u && !existing.includes(String(u.id)) && existing.length + added.length < 500) {
      added.push(String(u.id));
    }
  }

  if (!added.length) return { added: 0 };

  const now = new Date().toISOString();
  await db.update('groups', [{
    id,
    record: { ...g, participantIds: [...existing, ...added], updatedAt: now }
  }]);

  for (const uid of added) {
    await db.add('group_members', [{
      groupId: id,
      userId: uid,
      role: 'member',
      joinedAt: now,
      restricted: false
    }]);
  }

  return { added: added.length };
}

export async function removeMember(actorId: string, id: string, targetId: string) {
  const g = await getGroupRecord(id);
  const actor = await membership(id, actorId);
  const target = await membership(id, targetId);
  if (!g || !actor || !target) throw new Error('GROUP_NOT_FOUND');
  if (!isManager(actor)) throw new Error('PERMISSION_DENIED');
  if (target.role === 'owner') throw new Error('CANNOT_REMOVE_OWNER');
  if (actor.role === 'admin' && target.role === 'admin') throw new Error('PERMISSION_DENIED');

  const now = new Date().toISOString();
  await db.update('groups', [{
    id,
    record: { ...g, participantIds: g.participantIds.filter(x => x !== targetId), updatedAt: now }
  }]);
  if (target.id) await db.update('group_members', [{
    id: target.id,
    record: { ...target, leftAt: now }
  }]);
  return { removed: true };
}

export async function setMemberRole(actorId: string, id: string, targetId: string, role: 'admin' | 'member') {
  const actor = await membership(id, actorId);
  const target = await membership(id, targetId);
  if (!actor || !target) throw new Error('GROUP_NOT_FOUND');
  if (actor.role !== 'owner') throw new Error('PERMISSION_DENIED');
  if (target.role === 'owner') throw new Error('CANNOT_CHANGE_OWNER');
  if (target.id) await db.update('group_members', [{ id: target.id, record: { ...target, role } }]);
  return { role };
}

export async function setMemberRestricted(actorId: string, id: string, targetId: string, restricted: boolean) {
  const actor = await membership(id, actorId);
  const target = await membership(id, targetId);
  if (!actor || !target) throw new Error('GROUP_NOT_FOUND');
  if (!isManager(actor) || target.role === 'owner' || (actor.role === 'admin' && target.role === 'admin')) {
    throw new Error('PERMISSION_DENIED');
  }
  if (target.id) await db.update('group_members', [{ id: target.id, record: { ...target, restricted } }]);
  return { restricted };
}

export async function updateGroup(actorId: string, id: string, name: string, description: string, joinApproval?: boolean) {
  const g = await getGroupRecord(id);
  const actor = await membership(id, actorId);
  if (!g || !actor) throw new Error('GROUP_NOT_FOUND');
  if (!isManager(actor)) throw new Error('PERMISSION_DENIED');
  if (name.trim().length < 2 || name.trim().length > 80) throw new Error('INVALID_GROUP_NAME');

  const record = {
    ...g,
    name: name.trim(),
    description: description.trim().slice(0, 500),
    joinApproval: typeof joinApproval === 'boolean' ? joinApproval : g.joinApproval,
    updatedAt: new Date().toISOString()
  };
  await db.update('groups', [{ id, record }]);
  return { name: record.name, description: record.description, joinApproval: record.joinApproval };
}

export async function rotateInvite(actorId: string, id: string) {
  const g = await getGroupRecord(id);
  const actor = await membership(id, actorId);
  if (!g || !actor) throw new Error('GROUP_NOT_FOUND');
  if (!isManager(actor)) throw new Error('PERMISSION_DENIED');
  const code = inviteCode();
  await db.update('groups', [{ id, record: { ...g, inviteCode: code, updatedAt: new Date().toISOString() } }]);
  return { inviteCode: code };
}

export async function joinByInvite(userId: string, code: string) {
  const { items } = await db.list<Group>('groups', { limit: 100 });
  const g = items.find(x => String(x.inviteCode ?? '').toUpperCase() === code.trim().toUpperCase());
  if (!g) throw new Error('INVITE_NOT_FOUND');
  if (g.participantIds.includes(userId)) return { joined: true, pending: false, groupId: g.id, chatId: g.chatId };
  if (g.participantIds.length >= 500) throw new Error('GROUP_FULL');

  const existingRequest = (await db.list<any>('group_join_requests', { limit: 500 })).items
    .find(x => x.groupId === g.id && x.userId === userId && x.status === 'pending');

  if (g.joinApproval) {
    if (!existingRequest) {
      await db.add('group_join_requests', [{
        groupId: g.id,
        userId,
        status: 'pending',
        createdAt: new Date().toISOString()
      }]);
    }
    return { joined: false, pending: true, groupId: g.id };
  }

  const now = new Date().toISOString();
  await db.update('groups', [{
    id: g.id!,
    record: { ...g, participantIds: [...g.participantIds, userId], updatedAt: now }
  }]);
  await db.add('group_members', [{
    groupId: g.id,
    userId,
    role: 'member',
    joinedAt: now,
    restricted: false
  }]);
  const [chat] = await db.get<any>('chats', [g.chatId]);
  if (chat) await db.update('chats', [{ id: g.chatId, record: { ...chat, participantIds: [...chat.participantIds, userId], updatedAt: now } }]);
  return { joined: true, pending: false, groupId: g.id, chatId: g.chatId };
}

export async function approveJoin(actorId: string, requestId: string, approve: boolean) {
  const { items } = await db.list<any>('group_join_requests', { limit: 500 });
  const request = items.find(x => x.id === requestId && x.status === 'pending');
  if (!request) throw new Error('REQUEST_NOT_FOUND');
  const actor = await membership(request.groupId, actorId);
  if (!actor || !isManager(actor)) throw new Error('PERMISSION_DENIED');

  if (!approve) {
    await db.update('group_join_requests', [{ id: requestId, record: { ...request, status: 'rejected', resolvedAt: new Date().toISOString() } }]);
    return { approved: false };
  }

  const g = await getGroupRecord(request.groupId);
  if (!g || g.participantIds.length >= 500) throw new Error('GROUP_FULL');
  if (!g.participantIds.includes(request.userId)) {
    const now = new Date().toISOString();
    await db.update('groups', [{ id: g.id!, record: { ...g, participantIds: [...g.participantIds, request.userId], updatedAt: now } }]);
    await db.add('group_members', [{ groupId: g.id, userId: request.userId, role: 'member', joinedAt: now, restricted: false }]);
    const [chat] = await db.get<any>('chats', [g.chatId]);
    if (chat) await db.update('chats', [{ id: g.chatId, record: { ...chat, participantIds: [...chat.participantIds, request.userId], updatedAt: now } }]);
  }
  await db.update('group_join_requests', [{ id: requestId, record: { ...request, status: 'approved', resolvedAt: new Date().toISOString() } }]);
  return { approved: true };
}

export async function pendingJoinRequests(actorId: string, id: string) {
  const actor = await membership(id, actorId);
  if (!actor || !isManager(actor)) throw new Error('PERMISSION_DENIED');
  const { items } = await db.list<any>('group_join_requests', { limit: 500 });
  const requests = items.filter(x => x.groupId === id && x.status === 'pending');
  const users = await db.list<any>('users', { limit: 100 });
  return requests.map(r => {
    const u = users.items.find(x => String(x.id) === r.userId);
    return { id: r.id, userId: r.userId, username: u?.username ?? '', realName: u?.realName ?? '' };
  });
}

export async function leaveGroup(userId: string, id: string) {
  const g = await getGroupRecord(id);
  const me = await membership(id, userId);
  if (!g || !me) throw new Error('GROUP_NOT_FOUND');
  if (g.ownerId === userId) throw new Error('OWNER_CANNOT_LEAVE');
  const now = new Date().toISOString();
  await db.update('groups', [{
    id,
    record: { ...g, participantIds: g.participantIds.filter(x => x !== userId), updatedAt: now }
  }]);
  if (me.id) await db.update('group_members', [{ id: me.id, record: { ...me, leftAt: now } }]);
  const [chat] = await db.get<any>('chats', [g.chatId]);
  if (chat) await db.update('chats', [{ id: g.chatId, record: { ...chat, participantIds: chat.participantIds.filter((x: string) => x !== userId), updatedAt: now } }]);
  return { left: true };
}
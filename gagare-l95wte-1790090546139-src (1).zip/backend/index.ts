import { router, json, error } from '@appdeploy/sdk';
import { config } from './config';
import { checkDatabaseConnection } from './database';
import { logger } from './logger';
import { AGREEMENTS, createRegistration, isValidPhone, isValidUsername, normalizePhone, normalizeUsername, phoneExists, usernameExists } from './identity';
import { startPhoneVerification, verifyPhoneChallenge } from './verification';
import { authenticateLogin, clearSessionCookie, getSessionFromEvent, revokeAllUserSessions, revokeSession, sessionCookie } from './session';
import { changePassword, listUserSessions, recoverAccount, revokeSessionById, setupRecovery } from './security';
import { db } from '@appdeploy/sdk';
import { createDirectChat, listChats, listMessages, createMessage, editMessage, deleteMessage, forwardMessages, reactToMessage, markMessageOpened, setChatFlag, typingSignal } from './chat';
import { subscribeChat, unsubscribeChat } from './realtime';
import { uploadMedia, listMedia, getMediaUrl, consumeViewOnce } from './media';
import { createGroup, listGroups, getGroup, addMembers, removeMember, setMemberRole, setMemberRestricted, updateGroup, rotateInvite, joinByInvite, approveJoin, pendingJoinRequests, leaveGroup } from './group';
import { createStatus, listStatuses, getStatusMedia, markViewed, reactToStatus, listStatusViews, deleteStatus } from './status';
import { createCall, subscribeCallUser, subscribeCall, acceptCall, declineCall, joinCall, leaveCall, updateCallMedia, sendCallSignal, getCall, listCallHistory, markCallMissed, endCall } from './calls';
import { createStore, getMyStore, createListing, listListings, getListingPublic, updateStock, reviewListing, listReviews, reportListing, sellerAgreementStatus, acceptSellerAgreement, listCategories, listSavedListings, saveListing, unsaveListing, listListingMedia, uploadListingMedia } from './marketplace';

async function currentUser(userId: string) {
  const { items } = await db.list('users', { limit: 50 });
  return items.find(item => item.id === userId) ?? null;
}

export const handler = router({
  'GET /api/_healthcheck': [async () => json({ message: 'Success' })],
  'GET /api/v1/health': [async () => {
    const database = await checkDatabaseConnection();
    const status = database === 'connected' ? 'ok' : 'degraded';
    logger.info('Foundation health check', { status, database, environment: config.environment });
    return json({ data: { status, service: config.appName, environment: config.environment, database, version: config.version } }, status === 'ok' ? 200 : 503);
  }],
  'GET /api/v1/version': [async () => json({ data: { service: config.appName, apiVersion: config.apiVersion, version: config.version, environment: config.environment } })],
  'GET /api/v1/config': [async () => json({ data: { appName: config.appName, environment: config.environment, apiVersion: config.apiVersion, requirePhoneVerification: config.requirePhoneVerification } })],
  'GET /api/v1/agreements/current': [async () => json({ data: AGREEMENTS })],
  'GET /api/v1/identity/username-available': [async ({ query }) => {
    const username = normalizeUsername(query.username ?? '');
    if (!isValidUsername(username)) return json({ data: { available: false, reason: 'INVALID_USERNAME' } });
    return json({ data: { available: !(await usernameExists(username)) } });
  }],
  'POST /api/v1/identity/registration/start': [async ({ body }) => {
    const input = (body ?? {}) as { phoneNumber?: string };
    const phoneNumber = normalizePhone(String(input.phoneNumber ?? ''));
    if (!isValidPhone(phoneNumber)) return error('Invalid international phone number', 400);
    if (await phoneExists(phoneNumber)) return error('Phone number is already registered', 409);
    try { return json({ data: await startPhoneVerification(phoneNumber) }, 202); }
    catch (cause) { logger.error('Phone verification start failed', { error: cause instanceof Error ? cause.message : 'unknown' }); return error('Phone verification service is unavailable', 503); }
  }],
  'POST /api/v1/identity/registration/verify-phone': [async ({ body }) => {
    const input = (body ?? {}) as { challengeId?: string; otp?: string };
    if (!input.challengeId || !/^\d{6}$/.test(String(input.otp ?? ''))) return error('Invalid verification code', 400);
    const result = await verifyPhoneChallenge(input.challengeId, String(input.otp));
    if (!result.ok) return error(result.code === 'OTP_EXPIRED' ? 'Verification code expired' : result.code === 'OTP_ATTEMPTS_EXCEEDED' ? 'Too many verification attempts' : 'Invalid verification code', result.code === 'OTP_ATTEMPTS_EXCEEDED' ? 429 : 400);
    return json({ data: { verified: true } });
  }],
  'POST /api/v1/identity/registration/resend': [async ({ body }) => {
    const input = (body ?? {}) as { phoneNumber?: string };
    const phoneNumber = normalizePhone(String(input.phoneNumber ?? ''));
    if (!isValidPhone(phoneNumber)) return error('Invalid international phone number', 400);
    return error('SMS verification provider is not configured', 503);
  }],
  'POST /api/v1/identity/register': [async ({ body }) => {
    const input = (body ?? {}) as { phoneNumber?: string; realName?: string; username?: string; password?: string; phoneVerified?: boolean; acceptedAgreementIds?: string[] };
    const phoneNumber = normalizePhone(String(input.phoneNumber ?? ''));
    const realName = String(input.realName ?? '').trim();
    const username = normalizeUsername(String(input.username ?? ''));
    const password = String(input.password ?? '');
    const accepted = Array.isArray(input.acceptedAgreementIds) ? input.acceptedAgreementIds : [];
    if (!isValidPhone(phoneNumber)) return error('Invalid international phone number', 400);
    if (realName.length < 2 || realName.length > 80) return error('Real name must be 2-80 characters', 400);
    if (!isValidUsername(username)) return error('Username must be 3-24 lowercase letters, numbers, or underscores', 400);
    if (password.length < 8 || password.length > 128) return error('Password must be 8-128 characters', 400);
    if (config.requirePhoneVerification && input.phoneVerified !== true) return error('Phone ownership must be verified before account creation', 400);
    if (!AGREEMENTS.every(item => accepted.includes(item.id))) return error('All required agreements must be accepted', 400);
    try {
      const phoneVerified = config.requirePhoneVerification && input.phoneVerified === true;
      return json({ data: await createRegistration({ phoneNumber, realName, username, password, phoneVerified, acceptedAgreementIds: accepted }) }, 201);
    } catch (cause) {
      const code = cause instanceof Error ? cause.message : 'USER_CREATE_FAILED';
      if (code === 'USERNAME_TAKEN') return error('Username is already taken', 409);
      if (code === 'PHONE_ALREADY_REGISTERED') return error('Phone number is already registered', 409);
      logger.error('Registration failed', { code });
      return error('Account could not be created', 500);
    }
  }],
  'POST /api/v1/auth/login': [async ({ body }) => {
    const input = (body ?? {}) as { identifier?: string; password?: string };
    const identifier = String(input.identifier ?? '').trim();
    const password = String(input.password ?? '');
    if (!identifier || !password) return error('Username or phone and password are required', 400);
    try {
      const result = await authenticateLogin(identifier, password);
      if (!result) return error('Invalid credentials', 401);
      return {
        statusCode: 200,
        headers: { 'Content-Type': 'application/json', 'Set-Cookie': sessionCookie(result.token) },
        body: JSON.stringify({ data: { userId: result.userId, username: result.username, realName: result.realName, expiresAt: result.expiresAt } }),
      };
    } catch (cause) {
      logger.error('Login failed', { error: cause instanceof Error ? cause.message : 'unknown' });
      return error('Authentication service is unavailable', 503);
    }
  }],
  'GET /api/v1/auth/me': [async ({ event }) => {
    const found = await getSessionFromEvent(event);
    if (!found) return error('Authentication required', 401);
    const user = await currentUser(String(found.session.userId));
    if (!user || String(user.accountStatus) !== 'active') return error('Account is unavailable', 403);
    return json({ data: { userId: user.id, username: user.username, realName: user.realName, phoneNumber: user.phoneNumber, profilePhotoUrl: user.profilePhotoUrl ?? null } });
  }],
  'POST /api/v1/auth/logout': [async ({ event }) => {
    await revokeSession(event);
    return { statusCode: 200, headers: { 'Content-Type': 'application/json', 'Set-Cookie': clearSessionCookie() }, body: JSON.stringify({ data: { signedOut: true } }) };
  }],
  'POST /api/v1/auth/logout-all': [async ({ event }) => {
    const found = await getSessionFromEvent(event);
    if (!found) return error('Authentication required', 401);
    const count = await revokeAllUserSessions(String(found.session.userId));
    return { statusCode: 200, headers: { 'Content-Type': 'application/json', 'Set-Cookie': clearSessionCookie() }, body: JSON.stringify({ data: { signedOut: true, sessionsRevoked: count } }) };
  }],
  'GET /api/v1/auth/sessions': [async ({ event }) => {
    const found = await getSessionFromEvent(event);
    if (!found) return error('Authentication required', 401);
    const sessions = await listUserSessions(String(found.session.userId));
    return json({ data: { sessions: sessions.map(item => ({ ...item, current: item.id === found.session.id })) } });
  }],
  'POST /api/v1/auth/sessions/:id/revoke': [async ({ event, params }) => {
    const found = await getSessionFromEvent(event);
    if (!found) return error('Authentication required', 401);
    if (params.id === found.session.id) return error('Use sign out for the current session', 400);
    const ok = await revokeSessionById(String(found.session.userId), params.id);
    if (!ok) return error('Session not found', 404);
    return json({ data: { revoked: true } });
  }],
  'POST /api/v1/auth/change-password': [async ({ event, body }) => {
    const found = await getSessionFromEvent(event);
    if (!found) return error('Authentication required', 401);
    const input = (body ?? {}) as { currentPassword?: string; newPassword?: string };
    try { await changePassword(String(found.session.userId), String(input.currentPassword ?? ''), String(input.newPassword ?? '')); return json({ data: { changed: true } }); }
    catch (cause) { const code = cause instanceof Error ? cause.message : 'PASSWORD_CHANGE_FAILED'; return error(code === 'INVALID_PASSWORD' ? 'Current password is incorrect or the new password is invalid' : 'Password could not be changed', code === 'INVALID_PASSWORD' ? 400 : 500); }
  }],
  'POST /api/v1/auth/recovery/setup': [async ({ event, body }) => {
    const found = await getSessionFromEvent(event);
    if (!found) return error('Authentication required', 401);
    const input = (body ?? {}) as { currentPassword?: string; questions?: Array<{ question: string; answer: string }> };
    try { const result = await setupRecovery(String(found.session.userId), String(input.currentPassword ?? ''), input.questions ?? []); return json({ data: result }, 201); }
    catch (cause) { const code = cause instanceof Error ? cause.message : 'RECOVERY_SETUP_FAILED'; const messages: Record<string,string> = { INVALID_PASSWORD:'Current password is incorrect', THREE_QUESTIONS_REQUIRED:'Provide exactly 3 recovery questions', INVALID_RECOVERY_QUESTIONS:'Each question and answer must be valid', DUPLICATE_RECOVERY_QUESTIONS:'Recovery questions must be different' }; return error(messages[code] ?? 'Recovery setup failed', code === 'INVALID_PASSWORD' ? 401 : 400); }
  }],
  'POST /api/v1/auth/recovery/reset-password': [async ({ body }) => {
    const input = (body ?? {}) as { identifier?: string; recoveryKey?: string; answers?: string[]; newPassword?: string };
    try { const result = await recoverAccount(String(input.identifier ?? ''), String(input.recoveryKey ?? ''), input.answers ?? [], String(input.newPassword ?? '')); return json({ data: { reset: true, username: result.username } }); }
    catch (cause) { const code = cause instanceof Error ? cause.message : 'RECOVERY_FAILED'; const messages: Record<string,string> = { RECOVERY_LOCKED:'Recovery is temporarily locked after repeated failures', RECOVERY_NOT_CONFIGURED:'Recovery has not been configured for this account', INVALID_PASSWORD:'New password must be 8-128 characters', THREE_ANSWERS_REQUIRED:'Provide all 3 recovery answers', RECOVERY_FAILED:'Recovery details could not be verified', PASSWORD_RESET_FAILED:'Password could not be reset' }; return error(messages[code] ?? 'Recovery failed', code === 'RECOVERY_LOCKED' ? 429 : code === 'RECOVERY_NOT_CONFIGURED' ? 409 : 400); }
  }],
  'GET /api/v1/auth/session-status': [async ({ event }) => {
    const found = await getSessionFromEvent(event);
    return json({ data: { authenticated: Boolean(found), expiresAt: found?.session?.expiresAt ?? null } });
  }],
  'GET /api/v1/groups': [async ({ event }) => { const found=await getSessionFromEvent(event); if(!found)return error('Authentication required',401); return json({data:{groups:await listGroups(String(found.session.userId))}}); }],
  'POST /api/v1/groups/join': [async ({ event, body }) => { const found=await getSessionFromEvent(event); if(!found)return error('Authentication required',401); try{return json({data:await joinByInvite(String(found.session.userId),String((body as {code?:string})?.code??''))})}catch(cause){const code=cause instanceof Error?cause.message:'INVITE_NOT_FOUND';return error(code==='GROUP_FULL'?'Group is full':code==='INVITE_NOT_FOUND'?'Invite code not found':'Could not join group',code==='INVITE_NOT_FOUND'?404:400)} }],
  'POST /api/v1/groups': [async ({ event, body }) => { const found=await getSessionFromEvent(event); if(!found)return error('Authentication required',401); const input=(body??{}) as {name?:string;description?:string}; try{return json({data:await createGroup(String(found.session.userId),String(input.name??''),String(input.description??''))},201)}catch{return error('Group could not be created',400)} }],
  'GET /api/v1/groups/:id': [async ({ event, params }) => { const found=await getSessionFromEvent(event); if(!found)return error('Authentication required',401); try{return json({data:await getGroup(String(found.session.userId),params.id)})}catch{return error('Group not found',404)} }],
  'POST /api/v1/groups/:id/members': [async ({ event, params, body }) => { const found=await getSessionFromEvent(event); if(!found)return error('Authentication required',401); const input=(body??{}) as {usernames?:string[]}; try{return json({data:await addMembers(String(found.session.userId),params.id,Array.isArray(input.usernames)?input.usernames:[])})}catch(cause){const code=cause instanceof Error?cause.message:'ADD_MEMBER_FAILED';return error(code==='PERMISSION_DENIED'?'Only group admins can add members':code==='GROUP_NOT_FOUND'?'Group not found':'Members could not be added',code==='GROUP_NOT_FOUND'?404:403)} }],
  'POST /api/v1/groups/:id/members/:memberId/remove': [async ({ event, params }) => { const found=await getSessionFromEvent(event); if(!found)return error('Authentication required',401); try{return json({data:await removeMember(String(found.session.userId),params.id,params.memberId)})}catch(cause){const code=cause instanceof Error?cause.message:'REMOVE_MEMBER_FAILED';return error(code==='PERMISSION_DENIED'?'You do not have permission to remove this member':'Member could not be removed',403)} }],
  'POST /api/v1/groups/:id/members/:memberId/role': [async ({ event, params, body }) => { const found=await getSessionFromEvent(event); if(!found)return error('Authentication required',401); const role=(body as {role?:string})?.role==='admin'?'admin':'member'; try{return json({data:await setMemberRole(String(found.session.userId),params.id,params.memberId,role)})}catch{return error('Only the group owner can change admin roles',403)} }],
  'POST /api/v1/groups/:id/members/:memberId/restrict': [async ({ event, params, body }) => { const found=await getSessionFromEvent(event); if(!found)return error('Authentication required',401); try{return json({data:await setMemberRestricted(String(found.session.userId),params.id,params.memberId,Boolean((body as {restricted?:boolean})?.restricted))})}catch{return error('Member restriction was not allowed',403)} }],
  'POST /api/v1/groups/:id': [async ({ event, params, body }) => { const found=await getSessionFromEvent(event); if(!found)return error('Authentication required',401); const input=(body??{}) as {name?:string;description?:string;joinApproval?:boolean}; try{return json({data:await updateGroup(String(found.session.userId),params.id,String(input.name??''),String(input.description??''),input.joinApproval)})}catch{return error('Group settings could not be saved',403)} }],
  'POST /api/v1/groups/:id/invite/rotate': [async ({ event, params }) => { const found=await getSessionFromEvent(event); if(!found)return error('Authentication required',401); try{return json({data:await rotateInvite(String(found.session.userId),params.id)})}catch{return error('Invite could not be rotated',403)} }],
  'GET /api/v1/groups/:id/join-requests': [async ({ event, params }) => { const found=await getSessionFromEvent(event); if(!found)return error('Authentication required',401); try{return json({data:{requests:await pendingJoinRequests(String(found.session.userId),params.id)}})}catch{return error('Join requests are not available',403)} }],
  'POST /api/v1/groups/:id/join-requests/:requestId': [async ({ event, params, body }) => { const found=await getSessionFromEvent(event); if(!found)return error('Authentication required',401); try{return json({data:await approveJoin(String(found.session.userId),params.requestId,Boolean((body as {approve?:boolean})?.approve))})}catch{return error('Join request could not be resolved',403)} }],
  'POST /api/v1/groups/:id/leave': [async ({ event, params }) => { const found=await getSessionFromEvent(event); if(!found)return error('Authentication required',401); try{return json({data:await leaveGroup(String(found.session.userId),params.id)})}catch{return error('You cannot leave this group',400)} }],
  'GET /api/v1/chats': [async ({ event }) => { const found = await getSessionFromEvent(event); if (!found) return error('Authentication required', 401); return json({ data:{ chats:await listChats(String(found.session.userId)) } }); }],
  'POST /api/v1/chats': [async ({ event, body }) => { const found = await getSessionFromEvent(event); if (!found) return error('Authentication required', 401); try { return json({ data:await createDirectChat(String(found.session.userId), String((body as { username?:string })?.username ?? '')) }, 201); } catch (cause) { const code=cause instanceof Error?cause.message:'CHAT_CREATE_FAILED'; return error(code==='USER_NOT_FOUND'?'User not found':code==='CANNOT_CHAT_WITH_SELF'?'You cannot start a chat with yourself':'Chat could not be created', code==='USER_NOT_FOUND'?404:400); } }],
  'GET /api/v1/chats/:id/messages': [async ({ event, params }) => { const found=await getSessionFromEvent(event); if (!found) return error('Authentication required',401); try { return json({ data:{ messages:await listMessages(String(found.session.userId), params.id) } }); } catch { return error('Chat not found',404); } }],
  'POST /api/v1/chats/:id/messages': [async ({ event, params, body }) => { const found=await getSessionFromEvent(event); if (!found) return error('Authentication required',401); const input=(body??{}) as { ciphertext?:string; replyToMessageId?:string|null; forwardedFromMessageId?:string|null }; try { return json({ data:await createMessage(String(found.session.userId), params.id, String(input.ciphertext??''), input.replyToMessageId, input.forwardedFromMessageId) },201); } catch (cause) { const code=cause instanceof Error?cause.message:'MESSAGE_CREATE_FAILED'; return error(code==='MESSAGE_TOO_LARGE'?'Message is too large':code==='CHAT_NOT_FOUND'?'Chat not found':'Message could not be sent', code==='CHAT_NOT_FOUND'?404:400); } }],
  'POST /api/v1/chats/:id/messages/:messageId/reactions': [async ({ event, params, body }) => { const found=await getSessionFromEvent(event); if (!found) return error('Authentication required',401); try { await reactToMessage(String(found.session.userId),params.id,params.messageId,String((body as {emoji?:string})?.emoji??'')); return json({data:{reacted:true}}); } catch { return error('Reaction could not be added',400); } }],
  'POST /api/v1/chats/:id/messages/:messageId/opened': [async ({ event, params }) => { const found=await getSessionFromEvent(event); if (!found) return error('Authentication required',401); try { await markMessageOpened(String(found.session.userId),params.id,params.messageId); return json({data:{opened:true}}); } catch { return error('Message receipt could not be recorded',400); } }],
  'POST /api/v1/realtime/chat/subscribe': [async ({ event, body }) => { const found=await getSessionFromEvent(event); if (!found) return error('Authentication required',401); const input=(body??{}) as {chatId?:string;connectionId?:string}; if(!input.chatId||!input.connectionId) return error('chatId and connectionId are required',400); try { await listMessages(String(found.session.userId),input.chatId); await subscribeChat(input.chatId,input.connectionId); return json({data:{subscribed:true}}); } catch { return error('Chat not found',404); } }],
  'POST /api/v1/realtime/chat/unsubscribe': [async ({ event, body }) => { const found=await getSessionFromEvent(event); if (!found) return error('Authentication required',401); const input=(body??{}) as {chatId?:string;connectionId?:string}; if(!input.chatId||!input.connectionId) return error('chatId and connectionId are required',400); await unsubscribeChat(input.chatId,input.connectionId); return json({data:{unsubscribed:true}}); }],
  'POST /api/v1/chats/:id/media': [async ({ event, params, body }) => { const found=await getSessionFromEvent(event); if(!found)return error('Authentication required',401); const input=(body??{}) as {kind?:any;objectKey?:string;mimeType?:string;sizeBytes?:number;encryptedBase64?:string;viewOnce?:boolean}; try{return json({data:await uploadMedia(String(found.session.userId),params.id,{kind:input.kind,mimeType:String(input.mimeType??''),sizeBytes:Number(input.sizeBytes??0),encryptedBase64:String(input.encryptedBase64??''),viewOnce:Boolean(input.viewOnce)})},201)}catch(cause){const code=cause instanceof Error?cause.message:'MEDIA_CREATE_FAILED';return error(code==='MEDIA_TOO_LARGE'?'Media exceeds the 20 MB upload limit':'Media could not be registered',400)} }],
  'GET /api/v1/chats/:id/media': [async ({ event, params }) => { const found=await getSessionFromEvent(event); if(!found)return error('Authentication required',401); try{return json({data:{media:await listMedia(String(found.session.userId),params.id)}})}catch{return error('Chat not found',404)} }],
  'POST /api/v1/media/:id/view-once/consume': [async ({ event, params }) => { const found=await getSessionFromEvent(event); if(!found)return error('Authentication required',401); try{return json({data:await consumeViewOnce(String(found.session.userId),params.id)})}catch{return error('Media could not be opened',400)} }],
  'GET /api/v1/media/:id/url': [async ({ event, params }) => { const found=await getSessionFromEvent(event); if(!found)return error('Authentication required',401); try{return json({data:await getMediaUrl(String(found.session.userId),params.id)})}catch{return error('Media is unavailable',404)} }],
  'POST /api/v1/calls': [async ({ event, body }) => { const found=await getSessionFromEvent(event); if(!found)return error('Authentication required',401); const input=(body??{}) as {type?:'voice'|'video';chatId?:string;groupId?:string}; try{return json({data:await createCall(String(found.session.userId),{type:input.type==='video'?'video':'voice',chatId:input.chatId,groupId:input.groupId})},201)}catch(cause){const code=cause instanceof Error?cause.message:'CALL_CREATE_FAILED';return error(code==='CALL_NOT_AUTHORIZED'?'You are not a member of this call target':code==='INVALID_DIRECT_CALL'?'Invalid direct call target':'Call could not be started',code==='CALL_NOT_AUTHORIZED'?403:400)} }],
  'POST /api/v1/realtime/calls/user-subscribe': [async ({ event, body }) => { const found=await getSessionFromEvent(event); if(!found)return error('Authentication required',401); const input=(body??{}) as {connectionId?:string}; if(!input.connectionId)return error('connectionId is required',400); return json({data:await subscribeCallUser(String(found.session.userId),input.connectionId)}); }],
  'POST /api/v1/realtime/calls/:id/subscribe': [async ({ event, params, body }) => { const found=await getSessionFromEvent(event); if(!found)return error('Authentication required',401); const input=(body??{}) as {connectionId?:string}; if(!input.connectionId)return error('connectionId is required',400); try{return json({data:await subscribeCall(String(found.session.userId),params.id,input.connectionId)})}catch{return error('Call not found or access denied',403)} }],
  'GET /api/v1/calls/history': [async ({ event }) => { const found=await getSessionFromEvent(event); if(!found)return error('Authentication required',401); return json({data:{calls:await listCallHistory(String(found.session.userId))}}); }],
  'GET /api/v1/calls/:id': [async ({ event, params }) => { const found=await getSessionFromEvent(event); if(!found)return error('Authentication required',401); try{return json({data:await getCall(String(found.session.userId),params.id)})}catch{return error('Call not found or access denied',403)} }],
  'POST /api/v1/calls/:id/accept': [async ({ event, params }) => { const found=await getSessionFromEvent(event); if(!found)return error('Authentication required',401); try{return json({data:await acceptCall(String(found.session.userId),params.id)})}catch{return error('Call cannot be accepted',400)} }],
  'POST /api/v1/calls/:id/decline': [async ({ event, params }) => { const found=await getSessionFromEvent(event); if(!found)return error('Authentication required',401); try{return json({data:await declineCall(String(found.session.userId),params.id)})}catch{return error('Call cannot be declined',400)} }],
  'POST /api/v1/calls/:id/join': [async ({ event, params }) => { const found=await getSessionFromEvent(event); if(!found)return error('Authentication required',401); try{return json({data:await joinCall(String(found.session.userId),params.id)})}catch{return error('Call cannot be joined',400)} }],
  'POST /api/v1/calls/:id/leave': [async ({ event, params }) => { const found=await getSessionFromEvent(event); if(!found)return error('Authentication required',401); try{return json({data:await leaveCall(String(found.session.userId),params.id)})}catch{return error('Call cannot be left',400)} }],
  'POST /api/v1/calls/:id/missed': [async ({ event, params }) => { const found=await getSessionFromEvent(event); if(!found)return error('Authentication required',401); try{return json({data:await markCallMissed(String(found.session.userId),params.id)})}catch{return error('Call could not be marked missed',400)} }],
  'POST /api/v1/calls/:id/end': [async ({ event, params }) => { const found=await getSessionFromEvent(event); if(!found)return error('Authentication required',401); try{return json({data:await endCall(String(found.session.userId),params.id)})}catch{return error('Call cannot be ended',400)} }],
  'POST /api/v1/calls/:id/media': [async ({ event, params, body }) => { const found=await getSessionFromEvent(event); if(!found)return error('Authentication required',401); const input=(body??{}) as {muted?:boolean;cameraOff?:boolean}; try{return json({data:await updateCallMedia(String(found.session.userId),params.id,Boolean(input.muted),Boolean(input.cameraOff))})}catch{return error('Call media state could not be updated',400)} }],
  'POST /api/v1/calls/:id/signals': [async ({ event, params, body }) => { const found=await getSessionFromEvent(event); if(!found)return error('Authentication required',401); const input=(body??{}) as {targetUserId?:string;signalType?:string;payload?:unknown}; if(!input.targetUserId||!input.signalType)return error('targetUserId and signalType are required',400); try{return json({data:await sendCallSignal(String(found.session.userId),params.id,input.targetUserId,input.signalType,input.payload)})}catch{return error('Call signaling was rejected',403)} }],
  'GET /api/v1/marketplace/listings': [async ({ event, query }) => { const f=await getSessionFromEvent(event); if(!f)return error('Authentication required',401); return json({data:{listings:await listListings(query||{})}}); }],
  'GET /api/v1/marketplace/listings/:id': [async ({ event, params }) => { const f=await getSessionFromEvent(event); if(!f)return error('Authentication required',401); try{return json({data:await getListingPublic(params.id)})}catch{return error('Listing not found',404)} }],
  'GET /api/v1/marketplace/listings/:id/media': [async ({ event, params }) => { const f=await getSessionFromEvent(event); if(!f)return error('Authentication required',401); try{return json({data:{media:await listListingMedia(params.id)}})}catch{return error('Listing media is unavailable',404)} }],
  'POST /api/v1/marketplace/stores': [async ({ event, body }) => { const f=await getSessionFromEvent(event); if(!f)return error('Authentication required',401); try{return json({data:await createStore(String(f.session.userId),body||{})},201)}catch(e){return error(e instanceof Error?e.message:'Store creation failed',400)} }],
  'GET /api/v1/marketplace/seller-agreement': [async ({ event }) => { const f=await getSessionFromEvent(event); if(!f)return error('Authentication required',401); return json({data:{accepted:await sellerAgreementStatus(String(f.session.userId))}}); }],
  'POST /api/v1/marketplace/seller-agreement': [async ({ event }) => { const f=await getSessionFromEvent(event); if(!f)return error('Authentication required',401); return json({data:await acceptSellerAgreement(String(f.session.userId))},201); }],
  'GET /api/v1/marketplace/my-store': [async ({ event }) => { const f=await getSessionFromEvent(event); if(!f)return error('Authentication required',401); return json({data:{store:await getMyStore(String(f.session.userId))}}); }],
  'POST /api/v1/marketplace/listings': [async ({ event, body }) => { const f=await getSessionFromEvent(event); if(!f)return error('Authentication required',401); if(!await sellerAgreementStatus(String(f.session.userId)))return error('Seller agreement required',403); try{return json({data:await createListing(String(f.session.userId),body||{})},201)}catch(e){return error(e instanceof Error?e.message:'Listing creation failed',400)} }],
  'POST /api/v1/marketplace/listings/:id/stock': [async ({ event, params, body }) => { const f=await getSessionFromEvent(event); if(!f)return error('Authentication required',401); try{return json({data:await updateStock(String(f.session.userId),params.id,Number(((body||{}) as {quantity?:number}).quantity))})}catch(e){return error(e instanceof Error?e.message:'Stock update failed',400)} }],
  'POST /api/v1/marketplace/listings/:id/media': [async ({ event, params, body }) => { const f=await getSessionFromEvent(event); if(!f)return error('Authentication required',401); try{return json({data:await uploadListingMedia(String(f.session.userId),params.id,body||{})},201)}catch(e){const code=e instanceof Error?e.message:'MEDIA_UPLOAD_FAILED';return error(code==='SELLER_NOT_AUTHORIZED'?'Only the seller can add media':code==='MEDIA_TOO_LARGE'?'Each image or video must be 20 MB or smaller':code==='MEDIA_LIMIT'?'A listing can have up to 5 media items':code==='UNSUPPORTED_MEDIA'?'Only images and videos are supported':'Listing media could not be uploaded',400)} }],
  'POST /api/v1/marketplace/listings/:id/reviews': [async ({ event, params, body }) => { const f=await getSessionFromEvent(event); if(!f)return error('Authentication required',401); try{return json({data:await reviewListing(String(f.session.userId),params.id,Number(((body||{}) as {rating?:number}).rating),String(((body||{}) as {comment?:string}).comment||''))},201)}catch(e){return error(e instanceof Error?e.message:'Review failed',400)} }],
  'GET /api/v1/marketplace/listings/:id/reviews': [async ({ event, params }) => { const f=await getSessionFromEvent(event); if(!f)return error('Authentication required',401); return json({data:{reviews:await listReviews(params.id)}}); }],
  'POST /api/v1/marketplace/listings/:id/report': [async ({ event, params, body }) => { const f=await getSessionFromEvent(event); if(!f)return error('Authentication required',401); try{return json({data:await reportListing(String(f.session.userId),params.id,String(((body||{}) as {reason?:string}).reason||''))},201)}catch(e){return error(e instanceof Error?e.message:'Report failed',400)} }],
  'GET /api/v1/marketplace/categories': [async ({ event }) => { const f=await getSessionFromEvent(event); if(!f)return error('Authentication required',401); return json({data:{categories:await listCategories()}}); }],
  'GET /api/v1/marketplace/saved': [async ({ event }) => { const f=await getSessionFromEvent(event); if(!f)return error('Authentication required',401); return json({data:{listings:await listSavedListings(String(f.session.userId))}}); }],
  'POST /api/v1/marketplace/listings/:id/save': [async ({ event, params }) => { const f=await getSessionFromEvent(event); if(!f)return error('Authentication required',401); try{return json({data:await saveListing(String(f.session.userId),params.id)},201)}catch(e){return error(e instanceof Error?e.message:'Listing could not be saved',400)} }],
  'DELETE /api/v1/marketplace/listings/:id/save': [async ({ event, params }) => { const f=await getSessionFromEvent(event); if(!f)return error('Authentication required',401); try{return json({data:await unsaveListing(String(f.session.userId),params.id)})}catch(e){return error(e instanceof Error?e.message:'Listing could not be unsaved',400)} }],
  'GET /api/v1/statuses': [async ({ event }) => { const found=await getSessionFromEvent(event); if(!found)return error('Authentication required',401); try{return json({data:{statuses:await listStatuses(String(found.session.userId))}})}catch{return error('Statuses could not be loaded',500)} }],
  'POST /api/v1/statuses': [async ({ event, body }) => { const found=await getSessionFromEvent(event); if(!found)return error('Authentication required',401); const input=(body??{}) as {kind?:any;text?:string;mimeType?:string;encryptedBase64?:string;privacy?:any;selectedUserIds?:string[];viewOnce?:boolean}; try{return json({data:await createStatus(String(found.session.userId),{kind:input.kind,text:input.text,mimeType:input.mimeType,encryptedBase64:input.encryptedBase64,privacy:input.privacy,selectedUserIds:input.selectedUserIds,viewOnce:Boolean(input.viewOnce)})},201)}catch(cause){const code=cause instanceof Error?cause.message:'STATUS_CREATE_FAILED'; return error(code==='STATUS_TEXT_REQUIRED'?'Text Status cannot be empty':code==='STATUS_MEDIA_REQUIRED'?'Choose Status media':code==='STATUS_SELECTED_REQUIRED'?'Selected privacy requires at least one recipient':'Status could not be posted',400)} }],
  'GET /api/v1/statuses/:id/media': [async ({ event, params }) => { const found=await getSessionFromEvent(event); if(!found)return error('Authentication required',401); try{return json({data:await getStatusMedia(String(found.session.userId),params.id)})}catch(cause){const code=cause instanceof Error?cause.message:'STATUS_NOT_AVAILABLE'; return error(code==='STATUS_VIEW_ONCE_CONSUMED'?'This View Once Status has already been opened':'Status media is unavailable',404)} }],
  'POST /api/v1/statuses/:id/view': [async ({ event, params }) => { const found=await getSessionFromEvent(event); if(!found)return error('Authentication required',401); try{return json({data:await markViewed(String(found.session.userId),params.id)})}catch{return error('Status is unavailable',404)} }],
  'POST /api/v1/statuses/:id/reactions': [async ({ event, params, body }) => { const found=await getSessionFromEvent(event); if(!found)return error('Authentication required',401); try{return json({data:await reactToStatus(String(found.session.userId),params.id,String((body as {emoji?:string})?.emoji??''))})}catch{return error('Status reaction was not allowed',400)} }],
  'GET /api/v1/statuses/:id/views': [async ({ event, params }) => { const found=await getSessionFromEvent(event); if(!found)return error('Authentication required',401); try{return json({data:{views:await listStatusViews(String(found.session.userId),params.id)}})}catch{return error('Status not found',404)} }],
  'DELETE /api/v1/statuses/:id': [async ({ event, params }) => { const found=await getSessionFromEvent(event); if(!found)return error('Authentication required',401); try{return json({data:await deleteStatus(String(found.session.userId),params.id)})}catch{return error('Status not found',404)} }],
  'GET /api/v1/not-found-example': [async () => error('Resource not found', 404)],
});

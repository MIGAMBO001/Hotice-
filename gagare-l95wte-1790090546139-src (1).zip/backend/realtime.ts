import { db } from '@appdeploy/sdk';

export async function subscribeChat(chatId: string, connectionId: string) {
  const { items } = await db.list('realtime_subscriptions', { limit: 100 });
  const duplicate = items.find(item => String(item.entity_type) === 'chat' && String(item.entity_id) === chatId && String(item.connection_id) === connectionId);
  if (!duplicate) await db.add('realtime_subscriptions', [{ entity_type:'chat', entity_id:chatId, connection_id:connectionId, createdAt:new Date().toISOString() }]);
}

export async function unsubscribeChat(chatId: string, connectionId: string) {
  const { items } = await db.list('realtime_subscriptions', { limit: 100 });
  const ids = items.filter(item => String(item.entity_type) === 'chat' && String(item.entity_id) === chatId && String(item.connection_id) === connectionId).map(item => item.id);
  if (ids.length) await db.delete('realtime_subscriptions', ids);
}
import { createHash, randomBytes, timingSafeEqual } from 'node:crypto';
import { db } from '@appdeploy/sdk';
import { hashPassword, verifyPassword } from './password';
import { normalizePhone, normalizeUsername } from './identity';

const RECOVERY_LOCK_MS = 15 * 60 * 1000;
const MAX_FAILURES = 5;

function hashSecret(value: string) {
  return createHash('sha256').update(value).digest('hex');
}

function normalizeAnswer(value: string) {
  return value.trim().toLowerCase().replace(/\s+/g, ' ');
}

function equalHash(a: string, b: string) {
  const left = Buffer.from(a, 'hex');
  const right = Buffer.from(b, 'hex');
  return left.length === right.length && timingSafeEqual(left, right);
}

async function findUser(identifier: string) {
  const { items } = await db.list('users', { limit: 50 });
  const username = normalizeUsername(identifier);
  const phone = normalizePhone(identifier);
  return items.find(item => normalizeUsername(String(item.username ?? '')) === username || normalizePhone(String(item.phoneNumber ?? '')) === phone) ?? null;
}

async function activeRecovery(userId: string) {
  const { items } = await db.list('recovery_methods', { limit: 50 });
  return items.find(item => String(item.userId) === userId && String(item.status) === 'active') ?? null;
}

export async function setupRecovery(userId: string, currentPassword: string, questions: Array<{ question: string; answer: string }>) {
  const [user] = await db.get<Record<string, unknown>>('users', [userId]);
  if (!user || !verifyPassword(currentPassword, String(user.passwordHash ?? ''))) throw new Error('INVALID_PASSWORD');
  if (!Array.isArray(questions) || questions.length !== 3) throw new Error('THREE_QUESTIONS_REQUIRED');

  const cleaned = questions.map(item => ({ question: String(item.question ?? '').trim(), answer: normalizeAnswer(String(item.answer ?? '')) }));
  if (cleaned.some(item => item.question.length < 5 || item.question.length > 160 || item.answer.length < 3 || item.answer.length > 160)) throw new Error('INVALID_RECOVERY_QUESTIONS');
  if (new Set(cleaned.map(item => item.question.toLowerCase())).size !== 3) throw new Error('DUPLICATE_RECOVERY_QUESTIONS');

  const recoveryKey = randomBytes(32).toString('base64url');
  const now = new Date().toISOString();
  const [methodId] = await db.add('recovery_methods', [{
    userId,
    recoveryKeyHash: hashSecret(recoveryKey),
    questions: cleaned.map(item => ({ question: item.question, answerHash: hashSecret(item.answer) })),
    status: 'active',
    failedAttempts: 0,
    lockedUntil: null,
    createdAt: now,
    updatedAt: now
  }]);
  if (!methodId) throw new Error('RECOVERY_SETUP_FAILED');

  const { items } = await db.list('recovery_methods', { limit: 50 });
  const old = items.filter(item => String(item.userId) === userId && item.id !== methodId && String(item.status) === 'active');
  if (old.length) await db.update('recovery_methods', old.map(item => ({ id: item.id, record: { ...item, status: 'replaced', replacedAt: now } })));
  return { recoveryKey, createdAt: now };
}

export async function recoverAccount(identifier: string, recoveryKey: string, answers: string[], newPassword: string) {
  if (newPassword.length < 8 || newPassword.length > 128) throw new Error('INVALID_PASSWORD');
  if (!Array.isArray(answers) || answers.length !== 3) throw new Error('THREE_ANSWERS_REQUIRED');

  const user = await findUser(identifier);
  if (!user) throw new Error('RECOVERY_FAILED');
  const method = await activeRecovery(String(user.id));
  if (!method) throw new Error('RECOVERY_NOT_CONFIGURED');

  const now = Date.now();
  if (method.lockedUntil && Date.parse(String(method.lockedUntil)) > now) throw new Error('RECOVERY_LOCKED');

  const stored = Array.isArray(method.questions) ? method.questions as Array<{ answerHash?: string }> : [];
  const keyOk = equalHash(hashSecret(recoveryKey), String(method.recoveryKeyHash ?? ''));
  const answersOk = stored.length === 3 && answers.every((answer, index) => equalHash(hashSecret(normalizeAnswer(String(answer))), String(stored[index]?.answerHash ?? '')));

  if (!keyOk || !answersOk) {
    const failures = Number(method.failedAttempts ?? 0) + 1;
    const lockedUntil = failures >= MAX_FAILURES ? new Date(now + RECOVERY_LOCK_MS).toISOString() : null;
    await db.update('recovery_methods', [{ id: method.id, record: { ...method, failedAttempts: failures, lockedUntil, lastFailedAt: new Date(now).toISOString() } }]);
    await db.add('recovery_events', [{ userId: user.id, methodId: method.id, type: 'failed_recovery', createdAt: new Date(now).toISOString() }]);
    throw new Error(lockedUntil ? 'RECOVERY_LOCKED' : 'RECOVERY_FAILED');
  }

  const [updated] = await db.update('users', [{ id: user.id, record: { ...user, passwordHash: hashPassword(newPassword), passwordChangedAt: new Date(now).toISOString() } }]);
  if (!updated) throw new Error('PASSWORD_RESET_FAILED');
  await db.update('recovery_methods', [{ id: method.id, record: { ...method, failedAttempts: 0, lockedUntil: null, lastUsedAt: new Date(now).toISOString() } }]);
  await db.add('recovery_events', [{ userId: user.id, methodId: method.id, type: 'successful_recovery', createdAt: new Date(now).toISOString() }]);
  return { username: String(user.username) };
}

export async function changePassword(userId: string, currentPassword: string, newPassword: string) {
  if (newPassword.length < 8 || newPassword.length > 128) throw new Error('INVALID_PASSWORD');
  const [user] = await db.get<Record<string, unknown>>('users', [userId]);
  if (!user || !verifyPassword(currentPassword, String(user.passwordHash ?? ''))) throw new Error('INVALID_PASSWORD');
  const [ok] = await db.update('users', [{ id: userId, record: { ...user, passwordHash: hashPassword(newPassword), passwordChangedAt: new Date().toISOString() } }]);
  if (!ok) throw new Error('PASSWORD_CHANGE_FAILED');
}

export async function listUserSessions(userId: string) {
  const { items } = await db.list('sessions', { limit: 50 });
  return items.filter(item => String(item.userId) === userId).map(item => ({
    id: item.id,
    deviceType: item.deviceType ?? 'web',
    createdAt: item.createdAt,
    lastSeenAt: item.lastSeenAt,
    expiresAt: item.expiresAt,
    status: item.status
  }));
}

export async function revokeSessionById(userId: string, sessionId: string) {
  const [session] = await db.get<Record<string, unknown>>('sessions', [sessionId]);
  if (!session || String(session.userId) !== userId || String(session.status) !== 'active') return false;
  const [ok] = await db.update('sessions', [{ id: sessionId, record: { ...session, status: 'revoked', revokedAt: new Date().toISOString() } }]);
  return Boolean(ok);
}

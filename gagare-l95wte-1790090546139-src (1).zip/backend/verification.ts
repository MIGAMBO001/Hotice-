import { createHash, randomBytes } from 'node:crypto';
import { db } from '@appdeploy/sdk';
import { normalizePhone } from './identity';

const OTP_TTL_MS = 10 * 60 * 1000;
const RESEND_COOLDOWN_MS = 60 * 1000;
const MAX_ATTEMPTS = 5;

function hashOtp(challengeId: string, otp: string) {
  return createHash('sha256').update(challengeId + ':' + otp).digest('hex');
}

function createOtp() {
  return String(Math.floor(100000 + Math.random() * 900000));
}

export async function startPhoneVerification(phoneNumber: string) {
  const normalizedPhone = normalizePhone(phoneNumber);
  const challengeId = randomBytes(18).toString('hex');
  const now = Date.now();
  const expiresAt = now + OTP_TTL_MS;
  const otp = createOtp();

  const [id] = await db.add('verification_challenges', [{
    challengeId,
    phoneNumber: normalizedPhone,
    otpHash: hashOtp(challengeId, otp),
    createdAt: new Date(now).toISOString(),
    expiresAt: new Date(expiresAt).toISOString(),
    resendAvailableAt: new Date(now + RESEND_COOLDOWN_MS).toISOString(),
    attempts: 0,
    status: 'pending',
    provider: 'not_configured',
  }]);

  if (!id) throw new Error('VERIFICATION_CREATE_FAILED');

  return {
    challengeId,
    status: 'verification_pending',
    provider: 'not_configured',
    expiresAt: new Date(expiresAt).toISOString(),
    resendAvailableAt: new Date(now + RESEND_COOLDOWN_MS).toISOString(),
    message: 'Phone verification is ready for a real SMS provider. No OTP is exposed or accepted until a provider is configured.',
  };
}

export async function verifyPhoneChallenge(challengeId: string, otp: string) {
  const { items } = await db.list('verification_challenges', { limit: 50 });
  const challenge = items.find(item => item.challengeId === challengeId);

  if (!challenge || challenge.status !== 'pending') return { ok: false, code: 'OTP_INVALID' };
  if (Date.now() > Date.parse(String(challenge.expiresAt))) return { ok: false, code: 'OTP_EXPIRED' };

  const attempts = Number(challenge.attempts ?? 0);
  if (attempts >= MAX_ATTEMPTS) return { ok: false, code: 'OTP_ATTEMPTS_EXCEEDED' };

  const validFormat = /^\d{6}$/.test(otp);
  const valid = validFormat && hashOtp(challengeId, otp) === String(challenge.otpHash);

  await db.update('verification_challenges', [{
    id: challenge.id,
    record: { ...challenge, attempts: attempts + 1 },
  }]);

  if (!valid) return { ok: false, code: 'OTP_INVALID' };

  await db.update('verification_challenges', [{
    id: challenge.id,
    record: { ...challenge, attempts: attempts + 1, status: 'verified', verifiedAt: new Date().toISOString() },
  }]);

  return { ok: true };
}

import { db, ws } from '@appdeploy/sdk';

async function addSubscription(entityType: string, entityId: string, connectionId: string) {
  const { items } = await db.list('realtime_subscriptions', { limit: 100 });
  const duplicate = items.find(item => String(item.entity_type) === entityType && String(item.entity_id) === entityId && String(item.connection_id) === connectionId);
  if (!duplicate) await db.add('realtime_subscriptions', [{ entity_type: entityType, entity_id: entityId, connection_id: connectionId, createdAt: new Date().toISOString() }]);
}

async function notifySubscribers(entityType: string, entityId: string, payload: unknown) {
  const { items } = await db.list('realtime_subscriptions', { limit: 100 });
  const ids = Array.from(new Set(items.filter(item => String(item.entity_type) === entityType && String(item.entity_id) === entityId).map(item => String(item.connection_id))));
  if (ids.length) await ws.send(ids, { v: 1, type: 'entity.update', payload: { entity_type: entityType, entity_id: entityId, data: payload } });
}

type Call = {
  id?: string;
  type: 'voice' | 'video';
  scope: 'direct' | 'group';
  chatId?: string | null;
  groupId?: string | null;
  initiatorId: string;
  participantIds: string[];
  status: 'ringing' | 'active' | 'declined' | 'ended' | 'missed';
  createdAt: string;
  startedAt?: string;
  endedAt?: string;
};

type Participant = {
  id?: string;
  callId: string;
  userId: string;
  state: 'invited' | 'joined' | 'declined' | 'left';
  muted: boolean;
  cameraOff: boolean;
  joinedAt?: string;
  leftAt?: string;
};

async function getCallRecord(id: string) {
  const [call] = await db.get<Call>('calls', [id]);
  return call ? { ...call, id } : null;
}

async function getChat(id: string) {
  const [chat] = await db.get<any>('chats', [id]);
  return chat ? { ...chat, id } : null;
}

async function getGroup(id: string) {
  const [group] = await db.get<any>('groups', [id]);
  return group ? { ...group, id } : null;
}

async function participant(callId: string, userId: string) {
  const { items } = await db.list<Participant>('call_participants', { limit: 500 });
  return items.find(p => p.callId === callId && p.userId === userId && p.state !== 'left') ?? null;
}

async function requireParticipant(callId: string, userId: string) {
  const call = await getCallRecord(callId);
  const p = await participant(callId, userId);
  if (!call || !p) throw new Error('CALL_NOT_AUTHORIZED');
  return { call, participant: p };
}

async function notifyUsers(userIds: string[], payload: unknown) {
  for (const userId of Array.from(new Set(userIds))) {
    await notifySubscribers('user', userId, payload);
  }
}

export async function subscribeCallUser(userId: string, connectionId: string) {
  await addSubscription('user', userId, connectionId);
  return { subscribed: true };
}

export async function subscribeCall(userId: string, callId: string, connectionId: string) {
  await requireParticipant(callId, userId);
  await addSubscription('call', callId, connectionId);
  return { subscribed: true };
}

export async function createCall(userId: string, input: { type: 'voice' | 'video'; chatId?: string; groupId?: string }) {
  if (!['voice', 'video'].includes(input.type)) throw new Error('INVALID_CALL_TYPE');
  if (!input.chatId && !input.groupId) throw new Error('CALL_TARGET_REQUIRED');

  let participantIds: string[];
  let scope: 'direct' | 'group';
  if (input.chatId) {
    const chat = await getChat(input.chatId);
    if (!chat || chat.type !== 'direct' || !chat.participantIds?.includes(userId)) throw new Error('CALL_NOT_AUTHORIZED');
    participantIds = Array.from(new Set(chat.participantIds));
    if (participantIds.length !== 2) throw new Error('INVALID_DIRECT_CALL');
    scope = 'direct';
  } else {
    const group = await getGroup(String(input.groupId));
    if (!group || !group.participantIds?.includes(userId)) throw new Error('CALL_NOT_AUTHORIZED');
    participantIds = Array.from(new Set(group.participantIds));
    scope = 'group';
  }

  const now = new Date().toISOString();
  const [id] = await db.add('calls', [{
    type: input.type,
    scope,
    chatId: input.chatId ?? null,
    groupId: input.groupId ?? null,
    initiatorId: userId,
    participantIds: scope === 'direct' ? participantIds : [userId],
    status: 'ringing',
    createdAt: now
  }]);
  if (!id) throw new Error('CALL_CREATE_FAILED');

  await db.add('call_participants', [{
    callId: id,
    userId,
    state: 'joined',
    muted: false,
    cameraOff: input.type === 'voice',
    joinedAt: now
  }]);

  const invitees = participantIds.filter(x => x !== userId);
  if (invitees.length) {
    await db.add('call_participants', invitees.map(uid => ({
      callId: id,
      userId: uid,
      state: 'invited',
      muted: false,
      cameraOff: input.type === 'voice'
    })));
    await notifyUsers(invitees, {
      kind: 'call.invite',
      call: { id, type: input.type, scope, chatId: input.chatId ?? null, groupId: input.groupId ?? null, initiatorId: userId, participantIds: scope === 'direct' ? participantIds : [userId], status: 'ringing', createdAt: now }
    });
  }

  return { id, type: input.type, scope, chatId: input.chatId ?? null, groupId: input.groupId ?? null, initiatorId: userId, participantIds: scope === 'direct' ? participantIds : [userId], status: 'ringing', createdAt: now };
}

export async function acceptCall(userId: string, callId: string) {
  const { call, participant: p } = await requireParticipant(callId, userId);
  if (call.status === 'ended' || call.status === 'declined') throw new Error('CALL_ALREADY_ENDED');
  const now = new Date().toISOString();
  const nextCall: Call = { ...call, status: 'active', startedAt: call.startedAt ?? now };
  await db.update('calls', [{ id: callId, record: nextCall }]);
  await db.update('call_participants', [{ id: p.id!, record: { ...p, state: 'joined', joinedAt: p.joinedAt ?? now } }]);
  await notifySubscribers('call', callId, { kind: 'call.updated', call: nextCall, participant: { userId, state: 'joined' } });
  await notifyUsers(call.participantIds.filter(x => x !== userId), { kind: 'call.updated', call: nextCall, participant: { userId, state: 'joined' } });
  return nextCall;
}

export async function declineCall(userId: string, callId: string) {
  const { call, participant: p } = await requireParticipant(callId, userId);
  const now = new Date().toISOString();
  await db.update('call_participants', [{ id: p.id!, record: { ...p, state: 'declined', leftAt: now } }]);
  const nextStatus = call.scope === 'direct' ? 'declined' : call.status;
  const nextCall: Call = { ...call, status: nextStatus };
  await db.update('calls', [{ id: callId, record: nextCall }]);
  await notifySubscribers('call', callId, { kind: 'call.updated', call: nextCall, participant: { userId, state: 'declined' } });
  await notifyUsers(call.participantIds.filter(x => x !== userId), { kind: 'call.updated', call: nextCall, participant: { userId, state: 'declined' } });
  return nextCall;
}

export async function joinCall(userId: string, callId: string) {
  const { call, participant: p } = await requireParticipant(callId, userId);
  if (call.status === 'ended' || call.status === 'declined') throw new Error('CALL_ALREADY_ENDED');
  const now = new Date().toISOString();
  const nextParticipants = call.participantIds.includes(userId) ? call.participantIds : [...call.participantIds, userId];
  const nextCall: Call = { ...call, participantIds: nextParticipants, status: 'active', startedAt: call.startedAt ?? now };
  await db.update('calls', [{ id: callId, record: nextCall }]);
  await db.update('call_participants', [{ id: p.id!, record: { ...p, state: 'joined', joinedAt: p.joinedAt ?? now } }]);
  await notifySubscribers('call', callId, { kind: 'call.updated', call: nextCall, participant: { userId, state: 'joined' } });
  await notifyUsers(nextCall.participantIds.filter(x => x !== userId), { kind: 'call.updated', call: nextCall, participant: { userId, state: 'joined' } });
  return nextCall;
}

export async function leaveCall(userId: string, callId: string) {
  const { call, participant: p } = await requireParticipant(callId, userId);
  const now = new Date().toISOString();
  await db.update('call_participants', [{ id: p.id!, record: { ...p, state: 'left', leftAt: now } }]);
  const remaining = call.participantIds.filter(x => x !== userId);
  const nextStatus = remaining.length === 0 ? 'ended' : call.status;
  const nextCall: Call = { ...call, participantIds: remaining, status: nextStatus, endedAt: nextStatus === 'ended' ? now : call.endedAt };
  await db.update('calls', [{ id: callId, record: nextCall }]);
  await notifySubscribers('call', callId, { kind: 'call.updated', call: nextCall, participant: { userId, state: 'left' } });
  return nextCall;
}

export async function updateCallMedia(userId: string, callId: string, muted: boolean, cameraOff: boolean) {
  const { participant: p } = await requireParticipant(callId, userId);
  await db.update('call_participants', [{ id: p.id!, record: { ...p, muted, cameraOff } }]);
  await notifySubscribers('call', callId, { kind: 'call.media', userId, muted, cameraOff });
  return { muted, cameraOff };
}

export async function sendCallSignal(userId: string, callId: string, targetUserId: string, signalType: string, payload: unknown) {
  const { call } = await requireParticipant(callId, userId);
  if (!call.participantIds.includes(targetUserId)) throw new Error('CALL_TARGET_NOT_FOUND');
  if (!['offer', 'answer', 'ice-candidate', 'renegotiate'].includes(signalType)) throw new Error('INVALID_SIGNAL');
  const [id] = await db.add('call_signals', [{ callId, senderId: userId, targetUserId, signalType, payload, createdAt: new Date().toISOString() }]);
  await notifySubscribers('call', callId, { kind: 'call.signal', id, senderId: userId, targetUserId, signalType, payload });
  return { sent: true };
}

export async function getCall(userId: string, callId: string) {
  const { call } = await requireParticipant(callId, userId);
  const { items } = await db.list<Participant>('call_participants', { limit: 500 });
  return { ...call, participants: items.filter(p => p.callId === callId && p.state !== 'left').map(p => ({ userId: p.userId, state: p.state, muted: p.muted, cameraOff: p.cameraOff })) };
}

export async function listCallHistory(userId: string) {
  const { items } = await db.list<Call>('calls', { limit: 100 });
  return items.filter(c => c.participantIds.includes(userId) || c.initiatorId === userId).sort((a, b) => String(b.createdAt).localeCompare(String(a.createdAt))).slice(0, 50);
}

export async function markCallMissed(userId: string, callId: string) {
  const { call } = await requireParticipant(callId, userId);
  if (call.status !== 'ringing') return call;
  const now = new Date().toISOString();
  const nextCall: Call = { ...call, status: 'missed', endedAt: now };
  await db.update('calls', [{ id: callId, record: nextCall }]);
  await notifySubscribers('call', callId, { kind: 'call.updated', call: nextCall, participant: { userId, state: 'missed' } });
  await notifyUsers(call.participantIds.filter(x => x !== userId), { kind: 'call.updated', call: nextCall, participant: { userId, state: 'missed' } });
  return nextCall;
}

export async function endCall(userId: string, callId: string) {
  const { call } = await requireParticipant(callId, userId);
  const now = new Date().toISOString();
  const nextCall: Call = { ...call, status: 'ended', endedAt: now };
  await db.update('calls', [{ id: callId, record: nextCall }]);
  await notifySubscribers('call', callId, { kind: 'call.updated', call: nextCall, participant: { userId, state: 'left' } });
  return nextCall;
}

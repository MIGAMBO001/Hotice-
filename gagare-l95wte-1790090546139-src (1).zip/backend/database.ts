import { db } from '@appdeploy/sdk';
import { logger } from './logger';

export async function checkDatabaseConnection(): Promise<
  'connected' | 'unavailable'
> {
  try {
    await db.list('foundation_health', { limit: 1 });
    return 'connected';
  } catch (cause) {
    logger.error('Database health check failed', {
      error: cause instanceof Error ? cause.message : 'unknown_error',
    });
    return 'unavailable';
  }
}

export type AppEnvironment = 'development' | 'staging' | 'production';

const allowedEnvironments: AppEnvironment[] = [
  'development',
  'staging',
  'production',
];

function resolveEnvironment(): AppEnvironment {
  const value = process.env.APP_ENV;
  return allowedEnvironments.includes(value as AppEnvironment)
    ? (value as AppEnvironment)
    : 'production';
}

export const config = {
  appName: process.env.APP_NAME || 'HOTICE',
  environment: resolveEnvironment(),
  apiVersion: 'v1',
  version: process.env.APP_VERSION || '0.1.0-foundation',
  requirePhoneVerification: process.env.REQUIRE_PHONE_VERIFICATION === 'true',
};

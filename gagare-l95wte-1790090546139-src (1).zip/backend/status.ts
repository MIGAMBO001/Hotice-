import { db, storage, ws } from '@appdeploy/sdk';

type Status = {
  id?: string;
  userId: string;
  kind: 'image' | 'video' | 'voice' | 'sticker' | 'text';
  text?: string;
  mimeType?: string;
  objectPath?: string | null;
  privacy: 'everyone' | 'contacts' | 'selected' | 'nobody';
  selectedUserIds?: string[];
  viewOnce?: boolean;
  createdAt: string;
  expiresAt: string;
};

async function getStatus(id: string) {
  const [status] = await db.get<Status>('statuses', [id]);
  return status ? { ...status, id } : null;
}

async function isExpired(s: Status) {
  return Date.now() >= Date.parse(s.expiresAt);
}

async function areContacts(a: string, b: string) {
  const { items } = await db.list<any>('chats', { limit: 200 });
  return items.some(c => c.type === 'direct' && Array.isArray(c.participantIds) && c.participantIds.includes(a) && c.participantIds.includes(b));
}

async function canView(viewerId: string, status: Status) {
  if (status.userId === viewerId) return true;
  if (await isExpired(status)) return false;
  if (status.privacy === 'nobody') return false;
  if (status.privacy === 'everyone') return true;
  if (status.privacy === 'selected') return Boolean(status.selectedUserIds?.includes(viewerId));
  return areContacts(status.userId, viewerId);
}

async function viewed(statusId: string, viewerId: string) {
  const { items } = await db.list<any>('status_views', { limit: 500 });
  return items.find(x => x.statusId === statusId && x.viewerId === viewerId) ?? null;
}

export async function createStatus(userId: string, input: { kind: Status['kind']; text?: string; mimeType?: string; encryptedBase64?: string; privacy?: Status['privacy']; selectedUserIds?: string[]; viewOnce?: boolean }) {
  if (input.kind === 'text' && !String(input.text ?? '').trim()) throw new Error('STATUS_TEXT_REQUIRED');
  if (input.kind !== 'text' && !input.encryptedBase64) throw new Error('STATUS_MEDIA_REQUIRED');
  if (String(input.text ?? '').length > 1000) throw new Error('STATUS_TEXT_TOO_LONG');
  const privacy = input.privacy ?? 'everyone';
  if (privacy === 'selected' && (!input.selectedUserIds || input.selectedUserIds.length === 0)) throw new Error('STATUS_SELECTED_REQUIRED');
  const now = new Date();
  const expiresAt = new Date(now.getTime() + 12 * 60 * 60 * 1000);
  const id = crypto.randomUUID();
  let objectPath: string | null = null;
  if (input.kind !== 'text') {
    const safeType = String(input.mimeType ?? 'application/octet-stream').split('/')[1]?.replace(/[^a-z0-9]/gi, '').slice(0, 10) || 'bin';
    objectPath = 'statuses/' + userId + '/' + id + '.' + safeType;
    const [ok] = await storage.write([{ path: objectPath, content: String(input.encryptedBase64), contentType: String(input.mimeType ?? 'application/octet-stream') }]);
    if (!ok) throw new Error('STATUS_MEDIA_UPLOAD_FAILED');
  }
  const [recordId] = await db.add('statuses', [{
    userId,
    kind: input.kind,
    text: input.text?.trim() ?? '',
    mimeType: input.mimeType ?? null,
    objectPath,
    privacy,
    selectedUserIds: privacy === 'selected' ? Array.from(new Set(input.selectedUserIds ?? [])) : [],
    viewOnce: Boolean(input.viewOnce),
    createdAt: now.toISOString(),
    expiresAt: expiresAt.toISOString()
  }]);
  if (!recordId) throw new Error('STATUS_CREATE_FAILED');
  return { id: recordId, expiresAt: expiresAt.toISOString() };
}

export async function listStatuses(viewerId: string) {
  const { items } = await db.list<Status>('statuses', { limit: 200 });
  const visible = [];
  for (const s of items) {
    if (await isExpired(s)) continue;
    if (await canView(viewerId, s)) {
      const seen = await viewed(s.id!, viewerId);
      const url = s.objectPath && s.userId === viewerId ? (await storage.url([s.objectPath]))[0]?.url : null;
      visible.push({ ...s, objectPath: undefined, mediaUrl: url, seen: Boolean(seen) });
    }
  }
  return visible.sort((a, b) => Date.parse(b.createdAt) - Date.parse(a.createdAt));
}

export async function getStatusMedia(viewerId: string, id: string) {
  const s = await getStatus(id);
  if (!s || !(await canView(viewerId, s)) || !s.objectPath) throw new Error('STATUS_NOT_AVAILABLE');
  const existing = await viewed(id, viewerId);
  if (s.viewOnce && existing) throw new Error('STATUS_VIEW_ONCE_CONSUMED');
  const [{ url }] = await storage.url([s.objectPath]);
  if (!url) throw new Error('STATUS_MEDIA_UNAVAILABLE');
  return { url, viewOnce: Boolean(s.viewOnce) };
}

export async function markViewed(viewerId: string, id: string) {
  const s = await getStatus(id);
  if (!s || !(await canView(viewerId, s))) throw new Error('STATUS_NOT_AVAILABLE');
  if (s.userId !== viewerId && !(await viewed(id, viewerId))) {
    await db.add('status_views', [{ statusId: id, viewerId, viewedAt: new Date().toISOString() }]);
  }
  return { viewed: true };
}

export async function reactToStatus(viewerId: string, id: string, emoji: string) {
  const allowed = ['❤️', '👍', '👎', '😲', '😡', '🤗'];
  if (!allowed.includes(emoji)) throw new Error('INVALID_STATUS_REACTION');
  const s = await getStatus(id);
  if (!s || !(await canView(viewerId, s))) throw new Error('STATUS_NOT_AVAILABLE');
  const { items } = await db.list<any>('status_reactions', { limit: 500 });
  const existing = items.find(x => x.statusId === id && x.userId === viewerId);
  const record = { statusId: id, userId: viewerId, emoji, createdAt: new Date().toISOString() };
  if (existing) await db.update('status_reactions', [{ id: existing.id, record: { ...existing, ...record } }]);
  else await db.add('status_reactions', [record]);
  return { reacted: true, emoji };
}

export async function listStatusViews(ownerId: string, id: string) {
  const s = await getStatus(id);
  if (!s || s.userId !== ownerId) throw new Error('STATUS_NOT_FOUND');
  const { items } = await db.list<any>('status_views', { limit: 500 });
  const views = items.filter(x => x.statusId === id);
  const users = await db.list<any>('users', { limit: 200 });
  return views.map(v => {
    const u = users.items.find(x => x.id === v.viewerId);
    return { userId: v.viewerId, username: u?.username ?? '', realName: u?.realName ?? '', viewedAt: v.viewedAt };
  });
}

export async function deleteStatus(ownerId: string, id: string) {
  const s = await getStatus(id);
  if (!s || s.userId !== ownerId) throw new Error('STATUS_NOT_FOUND');
  if (s.objectPath) await storage.delete([s.objectPath]);
  await db.delete('statuses', [id]);
  return { deleted: true };
}
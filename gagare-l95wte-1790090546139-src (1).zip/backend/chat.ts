import { db, ws } from '@appdeploy/sdk';

type Chat = {
  id?: string;
  type: 'direct' | 'group';
  groupId?: string;
  participantIds: string[];
  createdAt: string;
  updatedAt: string;
  lastMessageAt?: string | null;
  archivedBy?: string[];
  mutedBy?: string[];
  hiddenBy?: string[];
};

type Message = {
  id?: string;
  chatId: string;
  senderId: string;
  ciphertext: string;
  createdAt: string;
  editedAt?: string | null;
  deletedAt?: string | null;
  replyToMessageId?: string | null;
  forwardedFromMessageId?: string | null;
};

async function getChat(id: string) {
  const [chat] = await db.get<Chat>('chats', [id]);
  return chat ? { ...chat, id } : null;
}

async function groupMember(chat: Chat | null, userId: string) {
  if (!chat || chat.type !== 'group') return null;
  const { items } = await db.list<any>('group_members', { limit: 500 });
  return items.find(x => x.groupId === chat.groupId && x.userId === userId && !x.leftAt) ?? null;
}

function inChat(userId: string, chat: Chat | null) {
  return Boolean(chat?.participantIds.includes(userId));
}

async function assertWritable(userId: string, chat: Chat | null) {
  if (!inChat(userId, chat)) throw new Error('CHAT_NOT_FOUND');
  const member = await groupMember(chat, userId);
  if (chat?.type === 'group' && member?.restricted) throw new Error('GROUP_MEMBER_RESTRICTED');
}

async function findUserByUsername(username: string) {
  const { items } = await db.list<any>('users', { limit: 50 });
  return items.find(
    x => String(x.username ?? '').toLowerCase() === username.trim().toLowerCase() &&
      String(x.accountStatus ?? 'active') === 'active'
  ) ?? null;
}

export async function listChats(userId: string) {
  const { items } = await db.list<Chat>('chats', { limit: 100 });
  return items
    .filter(c => (c.type === 'direct' || c.type === 'group') && c.participantIds.includes(userId))
    .sort((a, b) => Date.parse(String(b.updatedAt)) - Date.parse(String(a.updatedAt)))
    .map(c => ({
      ...c,
      id: c.id,
      archived: !!c.archivedBy?.includes(userId),
      muted: !!c.mutedBy?.includes(userId),
      hidden: !!c.hiddenBy?.includes(userId)
    }));
}

export async function createDirectChat(userId: string, username: string) {
  const target = await findUserByUsername(username);
  if (!target) throw new Error('USER_NOT_FOUND');
  if (String(target.id) === userId) throw new Error('CANNOT_CHAT_WITH_SELF');

  const participantIds = [userId, String(target.id)].sort();
  const { items } = await db.list<Chat>('chats', { limit: 100 });
  const existing = items.find(
    c => c.type === 'direct' &&
      c.participantIds.length === 2 &&
      c.participantIds[0] === participantIds[0] &&
      c.participantIds[1] === participantIds[1]
  );

  if (existing) {
    return {
      ...existing,
      id: existing.id,
      otherUser: {
        id: target.id,
        username: target.username,
        realName: target.realName,
        profilePhotoUrl: target.profilePhotoUrl ?? null
      }
    };
  }

  const now = new Date().toISOString();
  const [id] = await db.add('chats', [{
    type: 'direct',
    participantIds,
    createdAt: now,
    updatedAt: now,
    lastMessageAt: null,
    archivedBy: [],
    mutedBy: [],
    hiddenBy: []
  }]);
  if (!id) throw new Error('CHAT_CREATE_FAILED');

  return {
    id,
    type: 'direct',
    participantIds,
    createdAt: now,
    updatedAt: now,
    lastMessageAt: null,
    otherUser: {
      id: target.id,
      username: target.username,
      realName: target.realName,
      profilePhotoUrl: target.profilePhotoUrl ?? null
    }
  };
}

export async function listMessages(userId: string, chatId: string) {
  const chat = await getChat(chatId);
  if (!inChat(userId, chat)) throw new Error('CHAT_NOT_FOUND');

  const { items } = await db.list<Message>('messages', { limit: 200 });
  return items
    .filter(m => m.chatId === chatId && !m.deletedAt)
    .sort((a, b) => Date.parse(String(a.createdAt)) - Date.parse(String(b.createdAt)))
    .map(m => ({ ...m, id: m.id }));
}

export async function createMessage(
  userId: string,
  chatId: string,
  ciphertext: string,
  replyToMessageId?: string | null,
  forwardedFromMessageId?: string | null
) {
  if (!ciphertext || ciphertext.length > 100000) throw new Error('MESSAGE_TOO_LARGE');
  const chat = await getChat(chatId);
  await assertWritable(userId, chat);

  if (replyToMessageId) {
    const [reply] = await db.get<Message>('messages', [replyToMessageId]);
    if (!reply || reply.chatId !== chatId) throw new Error('REPLY_NOT_FOUND');
  }

  const now = new Date().toISOString();
  const [id] = await db.add('messages', [{
    chatId,
    senderId: userId,
    ciphertext,
    createdAt: now,
    editedAt: null,
    deletedAt: null,
    replyToMessageId: replyToMessageId ?? null,
    forwardedFromMessageId: forwardedFromMessageId ?? null
  }]);
  if (!id) throw new Error('MESSAGE_CREATE_FAILED');

  await db.update('chats', [{
    id: chat!.id!,
    record: { ...chat, updatedAt: now, lastMessageAt: now }
  }]);

  await notifyChat(chatId, {
    kind: 'message.created',
    message: {
      id,
      chatId,
      senderId: userId,
      ciphertext,
      createdAt: now,
      replyToMessageId: replyToMessageId ?? null,
      forwardedFromMessageId: forwardedFromMessageId ?? null
    }
  });

  return {
    id,
    chatId,
    senderId: userId,
    ciphertext,
    createdAt: now,
    replyToMessageId: replyToMessageId ?? null,
    forwardedFromMessageId: forwardedFromMessageId ?? null
  };
}

export async function editMessage(userId: string, id: string, ciphertext: string) {
  if (!ciphertext || ciphertext.length > 100000) throw new Error('MESSAGE_TOO_LARGE');
  const [message] = await db.get<Message>('messages', [id]);
  if (!message || message.senderId !== userId || message.deletedAt || Date.now() - Date.parse(message.createdAt) > 300000) {
    throw new Error('MESSAGE_NOT_EDITABLE');
  }
  const chat = await getChat(message.chatId);
  await assertWritable(userId, chat);
  const now = new Date().toISOString();
  await db.update('messages', [{ id, record: { ...message, ciphertext, editedAt: now } }]);
  await notifyChat(message.chatId, { kind: 'message.edited', message: { id, ciphertext, editedAt: now } });
  return { edited: true };
}

export async function deleteMessage(userId: string, id: string) {
  const [message] = await db.get<Message>('messages', [id]);
  if (!message || message.senderId !== userId) throw new Error('MESSAGE_NOT_FOUND');
  const chat = await getChat(message.chatId);
  await assertWritable(userId, chat);
  await db.update('messages', [{
    id,
    record: { ...message, ciphertext: '', deletedAt: new Date().toISOString() }
  }]);
  await notifyChat(message.chatId, { kind: 'message.deleted', messageId: id });
  return { deleted: true };
}

export async function forwardMessages(userId: string, messageIds: string[], recipientChatIds: string[]) {
  if (!messageIds.length || messageIds.length > 15) throw new Error('FORWARD_LIMIT_EXCEEDED');
  const recipients = Array.from(new Set(recipientChatIds));
  if (!recipients.length || recipients.length > 15) throw new Error('FORWARD_LIMIT_EXCEEDED');

  for (const chatId of recipients) {
    await assertWritable(userId, await getChat(chatId));
  }

  const { items } = await db.list<Message>('messages', { limit: 200 });
  const ids = new Set(messageIds);
  const source = items.filter(m => m.id && ids.has(String(m.id)) && m.senderId === userId && !m.deletedAt);
  if (source.length !== messageIds.length) throw new Error('MESSAGE_NOT_FOUND');

  for (const chatId of recipients) {
    for (const message of source) {
      await createMessage(userId, chatId, message.ciphertext, null, message.id);
    }
  }
  return { forwarded: true };
}

export async function reactToMessage(userId: string, chatId: string, messageId: string, emoji: string) {
  if (!emoji || emoji.length > 16) throw new Error('INVALID_REACTION');
  const chat = await getChat(chatId);
  if (!inChat(userId, chat)) throw new Error('CHAT_NOT_FOUND');
  const [message] = await db.get<Message>('messages', [messageId]);
  if (!message || message.chatId !== chatId) throw new Error('MESSAGE_NOT_FOUND');

  const { items } = await db.list('message_reactions', { limit: 200 });
  const existing = items.find(x => String(x.messageId) === messageId && String(x.userId) === userId);
  if (existing) {
    await db.update('message_reactions', [{ id: existing.id, record: { ...existing, emoji } }]);
  } else {
    await db.add('message_reactions', [{ messageId, chatId, userId, emoji, createdAt: new Date().toISOString() }]);
  }
  await notifyChat(chatId, { kind: 'message.reaction', messageId, userId, emoji });
}

export async function markMessageOpened(userId: string, chatId: string, messageId: string) {
  const chat = await getChat(chatId);
  if (!inChat(userId, chat)) throw new Error('CHAT_NOT_FOUND');
  const [message] = await db.get<Message>('messages', [messageId]);
  if (!message || message.chatId !== chatId) throw new Error('MESSAGE_NOT_FOUND');

  const { items } = await db.list('message_receipts', { limit: 200 });
  const existing = items.find(x => String(x.messageId) === messageId && String(x.userId) === userId);
  const now = new Date().toISOString();
  if (existing) {
    await db.update('message_receipts', [{ id: existing.id, record: { ...existing, deliveredAt: existing.deliveredAt ?? now, openedAt: now } }]);
  } else {
    await db.add('message_receipts', [{ messageId, chatId, userId, deliveredAt: now, openedAt: now }]);
  }
  await notifyChat(chatId, { kind: 'message.opened', messageId, userId, openedAt: now });
}

export async function setChatFlag(userId: string, chatId: string, flag: 'archive' | 'mute' | 'hide', enabled: boolean) {
  const chat = await getChat(chatId);
  if (!inChat(userId, chat)) throw new Error('CHAT_NOT_FOUND');
  const field = flag === 'archive' ? 'archivedBy' : flag === 'mute' ? 'mutedBy' : 'hiddenBy';
  const values = Array.isArray(chat[field]) ? chat[field]! : [];
  const next = enabled ? Array.from(new Set([...values, userId])) : values.filter(x => x !== userId);
  await db.update('chats', [{ id: chat.id!, record: { ...chat, [field]: next } }]);
  return { flag, enabled };
}

export async function typingSignal(userId: string, chatId: string, typing: boolean) {
  const chat = await getChat(chatId);
  if (!inChat(userId, chat)) throw new Error('CHAT_NOT_FOUND');
  await notifyChat(chatId, { kind: 'typing', userId, typing });
}

async function notifyChat(chatId: string, payload: unknown) {
  const { items } = await db.list('realtime_subscriptions', { limit: 500 });
  const ids = Array.from(new Set(
    items
      .filter(x => String(x.entity_type) === 'chat' && String(x.entity_id) === chatId)
      .map(x => String(x.connection_id))
  ));
  if (ids.length) {
    await ws.send(ids, {
      v: 1,
      type: 'entity.update',
      payload: { entity_type: 'chat', entity_id: chatId, data: payload }
    });
  }
}
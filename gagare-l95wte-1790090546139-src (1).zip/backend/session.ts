import { createHash, randomBytes } from 'node:crypto';
import { db } from '@appdeploy/sdk';
import { normalizePhone, normalizeUsername } from './identity';
import { verifyPassword } from './password';
import { config } from './config';

// Persistent sessions: inactivity must not sign the user out. The long defensive expiry is not an inactivity timer; explicit logout/revocation ends sessions.
const SESSION_TTL_MS = 10 * 365 * 24 * 60 * 60 * 1000;
const COOKIE_NAME = 'gagare_session';

function hashToken(token: string) {
  return createHash('sha256').update(token).digest('hex');
}

function makeToken() {
  return randomBytes(32).toString('base64url');
}

function cookie(value: string, maxAge: number) {
  return `${COOKIE_NAME}=${value}; Max-Age=${maxAge}; Path=/; HttpOnly; Secure; SameSite=Lax`;
}

export async function authenticateLogin(identifier: string, password: string) {
  const normalized = identifier.trim();
  const { items } = await db.list('users', { limit: 50 });
  const user = items.find(item =>
    normalizeUsername(String(item.username ?? '')) === normalizeUsername(normalized) ||
    normalizePhone(String(item.phoneNumber ?? '')) === normalizePhone(normalized)
  );

  if (!user || String(user.accountStatus ?? 'active') !== 'active') return null;
  if (!verifyPassword(password, String(user.passwordHash ?? ''))) return null;
  if (config.requirePhoneVerification && user.phoneVerified !== true) return null;

  const token = makeToken();
  const now = Date.now();
  const expiresAt = new Date(now + SESSION_TTL_MS).toISOString();
  const [sessionId] = await db.add('sessions', [{
    userId: user.id,
    tokenHash: hashToken(token),
    createdAt: new Date(now).toISOString(),
    lastSeenAt: new Date(now).toISOString(),
    expiresAt,
    status: 'active',
    deviceType: 'web',
  }]);

  if (!sessionId) throw new Error('SESSION_CREATE_FAILED');

  return {
    token,
    sessionId,
    userId: user.id,
    username: String(user.username),
    realName: String(user.realName),
    expiresAt,
  };
}

export async function getSessionFromEvent(event: { headers?: Record<string, string | undefined> }) {
  const rawCookie = Object.entries(event.headers ?? {}).find(([key]) => key.toLowerCase() === 'cookie')?.[1] ?? '';
  const match = rawCookie.split(';').map(part => part.trim()).find(part => part.startsWith(COOKIE_NAME + '='));
  if (!match) return null;

  const token = match.slice(COOKIE_NAME.length + 1);
  if (!token) return null;

  const { items } = await db.list('sessions', { limit: 500 });
  const session = items.find(item => String(item.tokenHash ?? '') === hashToken(token) && String(item.status) === 'active');
  if (!session) return null;
  // Never expire a session because of inactivity. The defensive timestamp is intentionally not checked here.

  return { session, token };
}

export async function revokeSession(event: { headers?: Record<string, string | undefined> }) {
  const found = await getSessionFromEvent(event);
  if (!found) return false;
  const [ok] = await db.update('sessions', [{
    id: found.session.id,
    record: { ...found.session, status: 'revoked', revokedAt: new Date().toISOString() },
  }]);
  return Boolean(ok);
}

export async function revokeAllUserSessions(userId: string) {
  const { items } = await db.list('sessions', { limit: 500 });
  const targets = items.filter(item => String(item.userId) === userId && String(item.status) === 'active');
  if (!targets.length) return 0;
  const results = await db.update('sessions', targets.map(item => ({
    id: item.id,
    record: { ...item, status: 'revoked', revokedAt: new Date().toISOString() },
  })));
  return results.filter(Boolean).length;
}

export function sessionCookie(token: string, maxAgeSeconds = SESSION_TTL_MS / 1000) {
  return cookie(token, maxAgeSeconds);
}

export function clearSessionCookie() {
  return cookie('', 0);
}

import { pbkdf2Sync, randomBytes, timingSafeEqual } from 'node:crypto';

const ITERATIONS = 210000;
const KEY_LENGTH = 32;
const DIGEST = 'sha256';

export function hashPassword(password: string) {
  const salt = randomBytes(16).toString('hex');
  const derived = pbkdf2Sync(password, salt, ITERATIONS, KEY_LENGTH, DIGEST).toString('hex');
  return `v1$pbkdf2-${DIGEST}$${ITERATIONS}$${salt}$${derived}`;
}

export function verifyPassword(password: string, storedHash: string) {
  const [version, algorithm, iterationsValue, salt, expected] = storedHash.split('$');
  if (version !== 'v1' || algorithm !== `pbkdf2-${DIGEST}` || !salt || !expected) return false;
  const iterations = Number(iterationsValue);
  if (!Number.isSafeInteger(iterations) || iterations < 100000) return false;
  const actual = pbkdf2Sync(password, salt, iterations, KEY_LENGTH, DIGEST).toString('hex');
  const actualBuffer = Buffer.from(actual, 'hex');
  const expectedBuffer = Buffer.from(expected, 'hex');
  return actualBuffer.length === expectedBuffer.length && timingSafeEqual(actualBuffer, expectedBuffer);
}

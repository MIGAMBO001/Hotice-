import { db } from '@appdeploy/sdk';
import { hashPassword } from './password';

export const AGREEMENTS = [
  { id: 'terms', title: 'Terms of Service', version: '1.0-draft' },
  { id: 'privacy', title: 'Privacy Policy', version: '1.0-draft' },
  { id: 'safety', title: 'Community & Safety Rules', version: '1.0-draft' },
] as const;

export interface RegistrationInput {
  phoneNumber: string;
  realName: string;
  username: string;
  password: string;
  profilePhotoUrl?: string;
  phoneVerified: boolean;
  acceptedAgreementIds: string[];
}

export function normalizePhone(value: string) {
  return value.replace(/[\s()\-]/g, '');
}

export function normalizeUsername(value: string) {
  return value.trim().toLowerCase();
}

export function isValidUsername(value: string) {
  return /^[a-z0-9_]{3,24}$/.test(value);
}

export function isValidPhone(value: string) {
  return /^\+[1-9]\d{7,14}$/.test(value);
}

async function findUsers() {
  const { items } = await db.list('users', { limit: 50 });
  return items;
}

export async function usernameExists(username: string) {
  const normalized = normalizeUsername(username);
  const users = await findUsers();
  return users.some(user => String(user.username ?? '').toLowerCase() === normalized);
}

export async function phoneExists(phoneNumber: string) {
  const normalized = normalizePhone(phoneNumber);
  const users = await findUsers();
  return users.some(user => normalizePhone(String(user.phoneNumber ?? '')) === normalized);
}

export async function createRegistration(input: RegistrationInput) {
  const username = normalizeUsername(input.username);
  const phoneNumber = normalizePhone(input.phoneNumber);

  if (await usernameExists(username)) throw new Error('USERNAME_TAKEN');
  if (await phoneExists(phoneNumber)) throw new Error('PHONE_ALREADY_REGISTERED');

  const [userId] = await db.add('users', [{
    realName: input.realName.trim(),
    username,
    phoneNumber,
    passwordHash: hashPassword(input.password),
    profilePhotoUrl: input.profilePhotoUrl ?? null,
    accountStatus: 'active',
    phoneVerified: input.phoneVerified,
      createdAt: new Date().toISOString(),
  }]);

  if (!userId) throw new Error('USER_CREATE_FAILED');

  const accepted = AGREEMENTS.filter(item => input.acceptedAgreementIds.includes(item.id));
  await db.add('user_agreements', accepted.map(item => ({
    userId,
    agreementId: item.id,
    agreementVersion: item.version,
    acceptedAt: new Date().toISOString(),
  })));

  return { userId, username };
}
